# JS-Apps-Exam-Skeleton
Run npm install before usage
