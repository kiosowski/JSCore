function solve() {
 // TODO
}