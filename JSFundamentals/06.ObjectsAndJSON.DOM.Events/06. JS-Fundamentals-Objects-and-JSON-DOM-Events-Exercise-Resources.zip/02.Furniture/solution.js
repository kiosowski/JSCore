function solve() {
  // TODO
}